local e = HeroLib
local t = HeroCache
local t = e.Unit
local a = t.Player
local a = t.Pet
local t = t.Target
local t = e.Spell
local e = e.Item
local e = HeroRotation
local e = t.Rogue.Assassination
local e = t.Rogue.Outlaw
local e = t.Rogue.Subtlety

